

def read_data(file_path):
    with open(file_path, 'r') as file:
        data = [list(map(int, line.strip().split())) for line in file]
    return data[0]  # assuming only one line in the file




# Calculate the sum of a list of integers
def calculate_sum(int_list):
    total = sum(int_list)
    return str(total) if total <= 510 else "Error: sum exceeds 510"


# Convert a decimal number to binary (base 2)
def decimal_to_binary(dec):
    bit_length = 8
    binary_value = [int(char) for char in format(int(dec), 'b').zfill(bit_length)]
    return binary_value


# Convert a binary (base 2) number to decimal
def binary_to_decimal(binary):
    s = 0
    i = 1
    for b in binary:
        s = s + (pow(2, len(binary) - i) * binary[b])
        i = i + 1
    return s


# Convert a dictionary to a string
def dict_to_string(dictionary):
    return ''.join(str(dictionary[l]) for l in dictionary)


# Convert a list to string
def list_to_string(string):
    return ''.join(str(elem) for elem in string if elem != " ")


# Verify the correctness of the MPC (Multi-Party Computation)
def verify_mpc(a, b, yao):
    if int(a) + int(b) == yao:
        return "The verification is successful: the sum is correct."
    else:
        return "The verification is unsuccessful: please try with smaller values."
